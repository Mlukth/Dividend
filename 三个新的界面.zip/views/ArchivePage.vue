<template>
  <div class="archive-page">
    <!-- 1. 电站概要信息 -->
    <el-card class="section-card overview-card">
      <template #header>
        <div class="card-header">
          <span class="card-title">电站概要信息</span>
        </div>
      </template>
      
      <div class="overview-content">
        <!-- 左侧：关键信息矩阵 -->
        <div class="info-matrix">
          <div class="info-item">
            <span class="info-icon">🏠</span>
            <div class="info-text">
              <div class="info-label">电站名称</div>
              <div class="info-value">赣州瑞金光伏电站</div>
            </div>
          </div>
          
          <div class="info-item">
            <span class="info-icon">📍</span>
            <div class="info-text">
              <div class="info-label">电站位置</div>
              <div class="info-value">江西省赣州市瑞金市</div>
            </div>
          </div>
          
          <div class="info-item">
            <span class="info-icon">⚡</span>
            <div class="info-text">
              <div class="info-label">装机容量</div>
              <div class="info-value">100,000 kW</div>
            </div>
          </div>
          
          <div class="info-item">
            <span class="info-icon">📅</span>
            <div class="info-text">
              <div class="info-label">投运时间</div>
              <div class="info-value">2023-06-15 (运行 637 天)</div>
            </div>
          </div>
          
          <div class="info-item">
            <span class="info-icon">🔋</span>
            <div class="info-text">
              <div class="info-label">电站类型</div>
              <el-tag type="info" class="station-tag">地面电站</el-tag>
            </div>
          </div>
          
          <div class="info-item">
            <span class="info-icon">🔌</span>
            <div class="info-text">
              <div class="info-label">并网电压等级</div>
              <div class="info-value">110 kV</div>
            </div>
          </div>
        </div>
        
        <!-- 右侧：仪表盘 + 图片轮播 -->
        <div class="visual-area">
          <div class="gauge-container">
            <div ref="gaugeRef" class="gauge-chart"></div>
            <div class="gauge-label">装机容量</div>
          </div>
          
          <el-carousel height="200px" class="station-carousel" :interval="3000" indicator-position="none">
            <el-carousel-item v-for="(item, index) in stationImages" :key="index">
              <div class="carousel-item" :style="{ backgroundImage: `url(${item})` }"></div>
            </el-carousel-item>
          </el-carousel>
        </div>
      </div>
    </el-card>

    <!-- 2. 设备台账 -->
    <el-card class="section-card equipment-card">
      <template #header>
        <div class="card-header">
          <span class="card-title">设备台账</span>
        </div>
      </template>
      
      <!-- 顶部图表区 -->
      <div class="charts-row">
        <div class="chart-item">
          <div ref="pieRef" class="small-chart"></div>
          <div class="chart-label">设备类型分布</div>
        </div>
        <div class="chart-item">
          <div ref="barRef" class="small-chart"></div>
          <div class="chart-label">厂家分布 TOP5</div>
        </div>
        <div class="chart-item">
          <div ref="lineRef" class="small-chart"></div>
          <div class="chart-label">安装时间趋势</div>
        </div>
      </div>
      
      <!-- 底部表格 -->
      <el-table 
        :data="equipmentData" 
        stripe 
        style="width: 100%"
        class="equipment-table"
        :row-class-name="tableRowClassName"
      >
        <el-table-column prop="stationName" label="电站名称" width="180" />
        <el-table-column prop="deviceType" label="设备类型" width="120">
          <template #default="scope">
            <el-tag size="small" :type="getDeviceTypeTag(scope.row.deviceType)">
              {{ scope.row.deviceType }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="model" label="型号" width="150" />
        <el-table-column prop="quantity" label="数量" width="80" />
        <el-table-column prop="coreParams" label="核心参数" />
        <el-table-column prop="manufacturer" label="生产厂家" width="180" />
        <el-table-column prop="installDate" label="安装日期" width="120" />
        <el-table-column label="操作" width="120">
          <template #default="scope">
            <el-button link type="primary" size="small">详情</el-button>
            <el-button link type="primary" size="small">文档</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 3. 设计图纸 -->
    <el-card class="section-card drawing-card">
      <template #header>
        <div class="card-header">
          <span class="card-title">设计图纸</span>
        </div>
      </template>
      
      <!-- 顶部缩略图墙 -->
      <div class="drawing-wall">
        <div v-for="(drawing, index) in drawings" :key="index" class="drawing-item">
          <div class="drawing-thumbnail">
            <span class="drawing-icon">{{ drawing.icon }}</span>
          </div>
          <div class="drawing-info">
            <div class="drawing-name">{{ drawing.name }}</div>
            <div class="drawing-meta">
              <span class="drawing-version" :class="{ latest: drawing.isLatest }">
                V{{ drawing.version }}
              </span>
              <span class="drawing-date">{{ drawing.updateDate }}</span>
            </div>
          </div>
          <div class="drawing-actions">
            <el-button link type="primary" size="small">预览</el-button>
            <el-button link type="primary" size="small">下载</el-button>
          </div>
        </div>
      </div>
      
      <!-- 底部表格 -->
      <el-table 
        :data="drawings" 
        stripe 
        style="width: 100%; margin-top: 20px"
        class="drawing-table"
      >
        <el-table-column prop="stationName" label="电站名称" width="180" />
        <el-table-column prop="type" label="图纸类型" width="120" />
        <el-table-column prop="code" label="图纸编号" width="150" />
        <el-table-column prop="version" label="版本号" width="80">
          <template #default="scope">
            <el-tag v-if="scope.row.isLatest" type="danger" size="small">
              V{{ scope.row.version }}
            </el-tag>
            <span v-else>V{{ scope.row.version }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="updateDate" label="更新日期" width="120" />
        <el-table-column label="操作">
          <template #default="scope">
            <el-button link type="primary" size="small">预览</el-button>
            <el-button link type="primary" size="small">下载</el-button>
            <el-button link type="info" size="small">历史</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'
import * as echarts from 'echarts'
import { ElTag, ElButton, ElTable, ElTableColumn, ElCard, ElCarousel, ElCarouselItem } from 'element-plus'

// --- 数据模拟 ---
const stationImages = [
  'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=600&h=400&fit=crop',
  'https://images.unsplash.com/photo-1497440001374-f26997328c1b?w=600&h=400&fit=crop',
  'https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?w=600&h=400&fit=crop'
]

const equipmentData = [
  { stationName: '赣州瑞金光伏电站', deviceType: '光伏组件', model: 'JKM395N-60HL4', quantity: 254000, coreParams: '395W, 单晶PERC', manufacturer: '晶科能源', installDate: '2023-03-10' },
  { stationName: '赣州瑞金光伏电站', deviceType: '逆变器', model: 'SUN2000-100KTL-M0', quantity: 1000, coreParams: '100kW, 三路MPPT', manufacturer: '华为技术', installDate: '2023-04-15' },
  { stationName: '赣州瑞金光伏电站', deviceType: '支架', model: 'ZJ-210-60', quantity: 42000, coreParams: '镀锌钢, 倾角25°', manufacturer: '中信博', installDate: '2023-02-20' },
  { stationName: '赣州瑞金光伏电站', deviceType: '箱变', model: 'ZGS11-Z-1250/35', quantity: 80, coreParams: '1250kVA, 35kV', manufacturer: '特变电工', installDate: '2023-05-08' }
]

const drawings = [
  { stationName: '赣州瑞金光伏电站', type: '电气主接线图', code: 'GR-PV-ELE-001', version: '2.1', updateDate: '2023-05-20', name: '110kV升压站主接线', icon: '📐', isLatest: true },
  { stationName: '赣州瑞金光伏电站', type: '总平面布置图', code: 'GR-PV-GEO-001', version: '1.5', updateDate: '2023-04-10', name: '电站总平面规划', icon: '🗺️', isLatest: false },
  { stationName: '赣州瑞金光伏电站', type: '设备基础图', code: 'GR-PV-STR-005', version: '3.0', updateDate: '2023-06-01', name: '逆变器基础施工图', icon: '🏗️', isLatest: true },
  { stationName: '赣州瑞金光伏电站', type: '接地网图', code: 'GR-PV-GRD-002', version: '1.0', updateDate: '2023-01-15', name: '全站接地系统', icon: '⚡', isLatest: false }
]

// --- DOM 引用 ---
const gaugeRef = ref(null)
const pieRef = ref(null)
const barRef = ref(null)
const lineRef = ref(null)

// --- 图表初始化 ---
onMounted(() => {
  nextTick(() => {
    initGaugeChart()
    initPieChart()
    initBarChart()
    initLineChart()
  })
})

const initGaugeChart = () => {
  const chart = echarts.init(gaugeRef.value)
  const option = {
    series: [{
      type: 'gauge',
      startAngle: 180,
      endAngle: 0,
      min: 0,
      max: 120000,
      splitNumber: 6,
      itemStyle: {
        color: '#0066CC'
      },
      progress: {
        show: true,
        width: 18
      },
      pointer: {
        show: false
      },
      axisLine: {
        lineStyle: {
          width: 18,
          color: [[1, '#E5E6EB']]
        }
      },
      axisTick: {
        show: false
      },
      splitLine: {
        show: false
      },
      axisLabel: {
        show: false
      },
      title: {
        show: false
      },
      detail: {
        valueAnimation: true,
        fontSize: 20,
        fontWeight: 'bold',
        color: '#1D2129',
        offsetCenter: [0, '20%'],
        formatter: '{value} kW'
      },
      data: [{
        value: 100000
      }]
    }]
  }
  chart.setOption(option)
}

const initPieChart = () => {
  const chart = echarts.init(pieRef.value)
  const option = {
    tooltip: {
      trigger: 'item'
    },
    series: [{
      type: 'pie',
      radius: ['40%', '70%'],
      center: ['50%', '50%'],
      avoidLabelOverlap: false,
      itemStyle: {
        borderRadius: 4,
        borderColor: '#fff',
        borderWidth: 2
      },
      label: {
        show: false
      },
      emphasis: {
        label: {
          show: true,
          fontSize: 12,
          fontWeight: 'bold'
        }
      },
      data: [
        { value: 254000, name: '光伏组件', itemStyle: { color: '#0066CC' } },
        { value: 1000, name: '逆变器', itemStyle: { color: '#165DFF' } },
        { value: 42000, name: '支架', itemStyle: { color: '#4080FF' } },
        { value: 80, name: '箱变', itemStyle: { color: '#6AA1FF' } }
      ]
    }]
  }
  chart.setOption(option)
}

const initBarChart = () => {
  const chart = echarts.init(barRef.value)
  const option = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      top: '10%',
      containLabel: true
    },
    xAxis: {
      type: 'value',
      show: false
    },
    yAxis: {
      type: 'category',
      data: ['阳光电源', '华为', '特变电工', '晶科', '中信博'],
      axisLabel: {
        fontSize: 10
      }
    },
    series: [{
      type: 'bar',
      data: [1200, 1000, 850, 600, 420],
      itemStyle: {
        color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
          { offset: 0, color: '#0066CC' },
          { offset: 1, color: '#4080FF' }
        ]),
        borderRadius: [0, 4, 4, 0]
      }
    }]
  }
  chart.setOption(option)
}

const initLineChart = () => {
  const chart = echarts.init(lineRef.value)
  const option = {
    tooltip: {
      trigger: 'axis'
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      top: '15%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: ['2022-Q4', '2023-Q1', '2023-Q2', '2023-Q3'],
      axisLabel: {
        fontSize: 10
      }
    },
    yAxis: {
      type: 'value',
      show: false
    },
    series: [{
      type: 'line',
      data: [0, 150, 320, 480],
      smooth: true,
      symbol: 'circle',
      symbolSize: 6,
      lineStyle: {
        color: '#0066CC',
        width: 2
      },
      itemStyle: {
        color: '#0066CC'
      },
      areaStyle: {
        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
          { offset: 0, color: 'rgba(0, 102, 204, 0.3)' },
          { offset: 1, color: 'rgba(0, 102, 204, 0.05)' }
        ])
      }
    }]
  }
  chart.setOption(option)
}

// --- 辅助函数 ---
const getDeviceTypeTag = (type) => {
  const map = {
    '光伏组件': '',
    '逆变器': 'warning',
    '支架': 'info',
    '箱变': 'danger'
  }
  return map[type] || ''
}

const tableRowClassName = ({ rowIndex }) => {
  return rowIndex % 2 === 0 ? '' : 'stripe-row'
}
</script>

<style scoped>
.archive-page {
  background-color: #F5F7FA;
  padding: 0;
  min-height: calc(100vh - 60px);
}

.section-card {
  margin-bottom: 20px;
  border-radius: 12px;
  border: none;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-title {
  font-size: 16px;
  font-weight: bold;
  color: #1D2129;
}

/* --- 电站概要样式 --- */
.overview-content {
  display: flex;
  gap: 40px;
}

.info-matrix {
  flex: 0 0 60%;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.info-icon {
  font-size: 24px;
}

.info-text {
  flex: 1;
}

.info-label {
  font-size: 12px;
  color: #86909C;
  margin-bottom: 4px;
}

.info-value {
  font-size: 14px;
  color: #1D2129;
  font-weight: 500;
}

.station-tag {
  background-color: #EEF7FF;
  color: #0066CC;
  border: none;
}

.visual-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 20px;
  align-items: center;
}

.gauge-container {
  width: 180px;
  height: 140px;
  position: relative;
}

.gauge-chart {
  width: 100%;
  height: 100%;
}

.gauge-label {
  text-align: center;
  font-size: 12px;
  color: #86909C;
  margin-top: -10px;
}

.station-carousel {
  width: 100%;
  border-radius: 8px;
  overflow: hidden;
}

.carousel-item {
  width: 100%;
  height: 100%;
  background-size: cover;
  background-position: center;
}

/* --- 设备台账样式 --- */
.charts-row {
  display: flex;
  justify-content: space-around;
  margin-bottom: 24px;
  padding-bottom: 24px;
  border-bottom: 1px solid #F2F3F5;
}

.chart-item {
  width: 30%;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.small-chart {
  width: 100%;
  height: 180px;
}

.chart-label {
  font-size: 12px;
  color: #86909C;
  margin-top: 8px;
}

.equipment-table {
  border-radius: 8px;
  overflow: hidden;
}

/* --- 设计图纸样式 --- */
.drawing-wall {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

.drawing-item {
  border: 1px solid #E5E6EB;
  border-radius: 8px;
  padding: 12px;
  transition: all 0.3s;
  cursor: pointer;
}

.drawing-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

.drawing-thumbnail {
  height: 100px;
  background-color: #F7F8FA;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 12px;
}

.drawing-icon {
  font-size: 40px;
}

.drawing-info {
  margin-bottom: 8px;
}

.drawing-name {
  font-size: 14px;
  font-weight: 500;
  color: #1D2129;
  margin-bottom: 4px;
}

.drawing-meta {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: #86909C;
}

.drawing-version.latest {
  color: #F53F3F;
  font-weight: bold;
}

.drawing-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}
</style>