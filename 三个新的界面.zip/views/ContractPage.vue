<template>
  <div class="contract-page">
    <!-- 1. 页面头部 -->
    <div class="page-header">
      <div class="header-left">
        <h1 class="main-title">电站合同信息</h1>
        <span class="sub-title">Contract Management</span>
      </div>
      <div class="header-right">
        <el-select v-model="contractStatus" placeholder="合同状态" class="status-filter">
          <el-option label="全部" value="" />
          <el-option label="生效中" value="active" />
          <el-option label="已到期" value="expired" />
          <el-option label="草稿" value="draft" />
        </el-select>
      </div>
    </div>

    <!-- 2. 合同类型标签页 -->
    <div class="tabs-container">
      <div 
        v-for="tab in tabs" 
        :key="tab.key"
        class="tab-item"
        :class="{ active: activeTab === tab.key }"
        @click="activeTab = tab.key"
      >
        {{ tab.label }}
      </div>
    </div>

    <!-- 3. 内容区域 -->
    <div class="content-area">
      <!-- EMC 合同内容 -->
      <div v-if="activeTab === 'emc'" class="contract-content">
        <!-- 3.1 顶部概览卡片 -->
        <div class="overview-card">
          <!-- 左侧：关键指标 -->
          <div class="metrics-section">
            <div class="metric-item">
              <div class="metric-icon roof-icon"></div>
              <div class="metric-info">
                <div class="metric-value">12,000 <span class="unit">㎡</span></div>
                <div class="metric-label">屋顶面积</div>
              </div>
            </div>
            <div class="metric-item">
              <div class="metric-icon clock-icon"></div>
              <div class="metric-info">
                <div class="metric-value green">8 <span class="unit">年</span></div>
                <div class="metric-label">剩余合作年限</div>
              </div>
            </div>
          </div>

          <!-- 中间：时间轴 -->
          <div class="timeline-section">
            <div class="timeline-title">合同状态进度</div>
            <div class="timeline">
              <div class="timeline-node completed">
                <div class="node-dot"></div>
                <div class="node-label">签订<br>2023-01-15</div>
              </div>
              <div class="timeline-line active"></div>
              <div class="timeline-node active">
                <div class="node-dot pulse"></div>
                <div class="node-label">生效中<br>2023-02-01</div>
              </div>
              <div class="timeline-line"></div>
              <div class="timeline-node">
                <div class="node-dot"></div>
                <div class="node-label">到期<br>2033-01-31</div>
              </div>
            </div>
          </div>

          <!-- 右侧：操作按钮 -->
          <div class="actions-section">
            <el-button class="btn-outline">查看附件</el-button>
            <el-button type="primary" class="btn-primary">导出合同</el-button>
          </div>
        </div>

        <!-- 3.2 中部详情网格 -->
        <div class="details-grid">
          <!-- 卡片1：基础信息 -->
          <div class="detail-card">
            <div class="card-title">基础信息</div>
            <div class="info-grid">
              <div class="info-item">
                <span class="info-label">电站名称</span>
                <span class="info-value">赣州瑞金市10MW光伏电站</span>
              </div>
              <div class="info-item">
                <span class="info-label">签订日期</span>
                <span class="info-value">2023-01-15</span>
              </div>
              <div class="info-item">
                <span class="info-label">合作方</span>
                <span class="info-value">瑞金市工业投资集团</span>
              </div>
              <div class="info-item">
                <span class="info-label">负责人</span>
                <span class="info-value">张三</span>
              </div>
              <div class="info-item">
                <span class="info-label">电话</span>
                <span class="info-value">138****1234</span>
              </div>
              <div class="info-item">
                <span class="info-label">合同状态</span>
                <span class="info-value status-active">生效中</span>
              </div>
            </div>
          </div>

          <!-- 卡片2：财务与屋顶信息 -->
          <div class="detail-card">
            <div class="card-title">财务与屋顶信息</div>
            <div class="info-grid">
              <div class="info-item">
                <span class="info-label">屋顶租金标准</span>
                <span class="info-value">8 元/㎡</span>
              </div>
              <div class="info-item">
                <span class="info-label">租金总额</span>
                <span class="info-value">96,000 元/年</span>
              </div>
              <div class="info-item">
                <span class="info-label">租赁期限</span>
                <span class="info-value">10 年</span>
              </div>
              <div class="info-item">
                <span class="info-label">电价折扣系数</span>
                <span class="info-value">0.85</span>
              </div>
            </div>
            <!-- 微型图表：租金趋势 -->
            <div class="mini-chart" ref="rentTrendChart"></div>
          </div>

          <!-- 卡片3：账户与支付 -->
          <div class="detail-card full-width">
            <div class="card-title">账户与支付</div>
            <div class="info-grid">
              <div class="info-item">
                <span class="info-label">账户名</span>
                <span class="info-value">瑞金市工业投资集团有限公司</span>
              </div>
              <div class="info-item">
                <span class="info-label">开户行</span>
                <span class="info-value">中国工商银行瑞金支行</span>
              </div>
              <div class="info-item">
                <span class="info-label">银行账号</span>
                <span class="info-value">1502 0231 0900 0012 345</span>
              </div>
              <div class="info-item">
                <span class="info-label">支付周期</span>
                <span class="info-value">按季度支付</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 3.3 底部附件区 -->
        <div class="attachments-section">
          <div class="section-title">合同附件</div>
          <div class="attachments-list">
            <div class="attachment-item">
              <div class="file-icon pdf-icon"></div>
              <div class="file-info">
                <div class="file-name">EMC合同正本.pdf</div>
                <div class="file-size">2.3 MB</div>
              </div>
            </div>
            <div class="attachment-item">
              <div class="file-icon excel-icon"></div>
              <div class="file-info">
                <div class="file-name">租金计算表.xlsx</div>
                <div class="file-size">156 KB</div>
              </div>
            </div>
            <div class="attachment-item">
              <div class="file-icon img-icon"></div>
              <div class="file-info">
                <div class="file-name">屋顶平面图.png</div>
                <div class="file-size">4.8 MB</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- EPC 合同内容 (简略展示) -->
      <div v-if="activeTab === 'epc'" class="contract-content">
        <div class="overview-card">
          <div class="metrics-section">
            <div class="metric-item">
              <div class="metric-value">4.2 <span class="unit">元/W</span></div>
              <div class="metric-label">投资单价</div>
            </div>
            <div class="metric-item">
              <div class="metric-value">42,000,000 <span class="unit">元</span></div>
              <div class="metric-label">投资总额</div>
            </div>
          </div>
          <div class="chart-section" ref="ganttChart"></div>
        </div>
        <div class="details-grid">
          <div class="detail-card">
            <div class="card-title">EPC施工信息</div>
            <div class="info-grid">
              <div class="info-item"><span class="info-label">总包公司</span><span class="info-value">中国电建集团江西设计院</span></div>
              <div class="info-item"><span class="info-label">施工周期</span><span class="info-value">180 天</span></div>
              <div class="info-item"><span class="info-label">开工时间</span><span class="info-value">2023-03-01</span></div>
              <div class="info-item"><span class="info-label">并网时间</span><span class="info-value">2023-08-28</span></div>
            </div>
          </div>
          <div class="detail-card">
            <div class="card-title">设备品牌分布</div>
            <div class="pie-chart" ref="brandPieChart"></div>
          </div>
        </div>
      </div>

      <!-- 其他合同类型占位 -->
      <div v-if="activeTab === 'purchase'" class="contract-content">
        <el-empty description="购售电合同内容开发中..." />
      </div>
      <div v-if="activeTab === 'financing'" class="contract-content">
        <el-empty description="融资合同内容开发中..." />
      </div>
      <div v-if="activeTab === 'operation'" class="contract-content">
        <el-empty description="运维合同内容开发中..." />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import * as echarts from 'echarts'
import { ElButton, ElSelect, ElOption, ElEmpty } from 'element-plus'

// 响应式数据
const activeTab = ref('emc')
const contractStatus = ref('')

// 标签页配置
const tabs = [
  { key: 'emc', label: 'EMC合同' },
  { key: 'epc', label: 'EPC合同' },
  { key: 'purchase', label: '购售电合同' },
  { key: 'financing', label: '融资合同' },
  { key: 'operation', label: '运维合同' }
]

// 图表引用
const rentTrendChart = ref(null)
const ganttChart = ref(null)
const brandPieChart = ref(null)

// 初始化 EMC 租金趋势图
const initRentTrendChart = () => {
  if (!rentTrendChart.value) return
  const chart = echarts.init(rentTrendChart.value)
  chart.setOption({
    grid: { top: 10, right: 10, bottom: 20, left: 30 },
    xAxis: {
      type: 'category',
      data: ['2019', '2020', '2021', '2022', '2023'],
      axisLine: { lineStyle: { color: '#E5E6EB' } },
      axisLabel: { color: '#86909C', fontSize: 10 }
    },
    yAxis: {
      type: 'value',
      splitLine: { lineStyle: { color: '#F5F7FA' } },
      axisLabel: { color: '#86909C', fontSize: 10 }
    },
    series: [{
      data: [7.5, 7.8, 8.0, 8.0, 8.0],
      type: 'bar',
      itemStyle: {
        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
          { offset: 0, color: '#0066CC' },
          { offset: 1, color: '#165DFF' }
        ]),
        borderRadius: [4, 4, 0, 0]
      }
    }]
  })
}

// 初始化 EPC 甘特图 (简化版)
const initGanttChart = () => {
  if (!ganttChart.value) return
  const chart = echarts.init(ganttChart.value)
  chart.setOption({
    tooltip: { trigger: 'axis' },
    grid: { top: 30, right: 30, bottom: 30, left: 80 },
    xAxis: {
      type: 'time',
      min: '2023-03-01',
      max: '2023-09-01'
    },
    yAxis: {
      type: 'category',
      data: ['并网', '竣工', '组件到场', '开工'],
      inverse: true
    },
    series: [{
      type: 'bar',
      data: [
        ['2023-08-20', '2023-08-28', '并网', 1],
        ['2023-08-10', '2023-08-20', '竣工', 2],
        ['2023-05-15', '2023-06-01', '组件到场', 3],
        ['2023-03-01', '2023-03-15', '开工', 4]
      ],
      itemStyle: { color: '#0066CC', borderRadius: 4 }
    }]
  })
}

// 初始化设备品牌饼图
const initBrandPieChart = () => {
  if (!brandPieChart.value) return
  const chart = echarts.init(brandPieChart.value)
  chart.setOption({
    tooltip: { trigger: 'item' },
    legend: { bottom: 0 },
    series: [{
      type: 'pie',
      radius: ['40%', '70%'],
      avoidLabelOverlap: false,
      itemStyle: { borderRadius: 4, borderColor: '#fff', borderWidth: 2 },
      label: { show: false },
      data: [
        { value: 40, name: '隆基组件', itemStyle: { color: '#0066CC' } },
        { value: 30, name: '阳光电源', itemStyle: { color: '#165DFF' } },
        { value: 20, name: '华为逆变器', itemStyle: { color: '#52C41A' } },
        { value: 10, name: '其他', itemStyle: { color: '#86909C' } }
      ]
    }]
  })
}

// 组件挂载后初始化图表
onMounted(() => {
  initRentTrendChart()
  initGanttChart()
  initBrandPieChart()
  
  // 响应窗口大小变化
  window.addEventListener('resize', () => {
    rentTrendChart.value && echarts.getInstanceByDom(rentTrendChart.value)?.resize()
    ganttChart.value && echarts.getInstanceByDom(ganttChart.value)?.resize()
    brandPieChart.value && echarts.getInstanceByDom(brandPieChart.value)?.resize()
  })
})
</script>

<style scoped>
/* 页面整体布局 */
.contract-page {
  background-color: #F5F7FA;
  min-height: 100%;
  padding: 10px;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
}

/* 页面头部 */
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding: 0 10px;
}

.header-left {
  display: flex;
  align-items: baseline;
  gap: 12px;
}

.main-title {
  font-size: 20px;
  font-weight: 600;
  color: #1D2129;
  margin: 0;
}

.sub-title {
  font-size: 14px;
  color: #86909C;
}

.status-filter {
  width: 150px;
}

/* 标签页 */
.tabs-container {
  display: flex;
  gap: 8px;
  margin-bottom: 20px;
  padding: 0 10px;
}

.tab-item {
  padding: 8px 20px;
  border-radius: 8px;
  font-size: 14px;
  color: #4E5969;
  background-color: #FFFFFF;
  cursor: pointer;
  transition: all 0.3s ease;
}

.tab-item:hover {
  background-color: #F5F7FA;
}

.tab-item.active {
  background: linear-gradient(90deg, #0066CC, #165DFF);
  color: #FFFFFF;
  font-weight: 500;
}

/* 内容区域 */
.content-area {
  padding: 0 10px;
}

/* 概览卡片 */
.overview-card {
  background-color: #FFFFFF;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);
  padding: 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

/* 关键指标 */
.metrics-section {
  display: flex;
  gap: 40px;
}

.metric-item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.metric-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background-size: 24px;
  background-repeat: no-repeat;
  background-position: center;
}

.roof-icon {
  background-color: #EEF7FF;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%230066CC' viewBox='0 0 24 24'%3E%3Cpath d='M14 11h4v7h-4zm-6 0h4v7H8zm-3 0h2v7H5zM12 3L2 9v1h20V9z'/%3E%3C/svg%3E");
}

.clock-icon {
  background-color: #E8FFEA;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%2352C41A' viewBox='0 0 24 24'%3E%3Cpath d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z'/%3E%3C/svg%3E");
}

.metric-value {
  font-size: 24px;
  font-weight: 600;
  color: #0066CC;
  line-height: 1.2;
}

.metric-value.green {
  color: #52C41A;
}

.metric-value .unit {
  font-size: 14px;
  font-weight: 400;
}

.metric-label {
  font-size: 13px;
  color: #86909C;
}

/* 时间轴 */
.timeline-section {
  flex: 1;
  padding: 0 40px;
}

.timeline-title {
  font-size: 14px;
  color: #1D2129;
  margin-bottom: 16px;
  font-weight: 500;
}

.timeline {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.timeline-node {
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
}

.node-dot {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background-color: #E5E6EB;
  margin-bottom: 8px;
}

.timeline-node.completed .node-dot {
  background-color: #52C41A;
}

.timeline-node.active .node-dot {
  background-color: #52C41A;
}

.node-dot.pulse {
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0% { box-shadow: 0 0 0 0 rgba(82, 196, 26, 0.4); }
  70% { box-shadow: 0 0 0 10px rgba(82, 196, 26, 0); }
  100% { box-shadow: 0 0 0 0 rgba(82, 196, 26, 0); }
}

.node-label {
  font-size: 12px;
  color: #86909C;
  text-align: center;
  line-height: 1.4;
}

.timeline-node.active .node-label {
  color: #52C41A;
  font-weight: 500;
}

.timeline-line {
  flex: 1;
  height: 2px;
  background-color: #E5E6EB;
  margin: 0 10px;
  margin-bottom: 20px;
}

.timeline-line.active {
  background-color: #52C41A;
}

/* 操作按钮 */
.actions-section {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.btn-outline {
  border-color: #0066CC;
  color: #0066CC;
  border-radius: 8px;
}

.btn-primary {
  background: linear-gradient(90deg, #0066CC, #165DFF);
  border: none;
  border-radius: 8px;
}

/* 详情网格 */
.details-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-bottom: 20px;
}

.detail-card {
  background-color: #FFFFFF;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);
  padding: 20px;
}

.detail-card.full-width {
  grid-column: 1 / -1;
}

.card-title {
  font-size: 16px;
  font-weight: 600;
  color: #1D2129;
  margin-bottom: 16px;
  padding-bottom: 12px;
  border-bottom: 1px solid #F5F7FA;
}

.info-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px 24px;
}

.info-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.info-label {
  font-size: 13px;
  color: #86909C;
}

.info-value {
  font-size: 14px;
  color: #1D2129;
  font-weight: 500;
}

.status-active {
  color: #52C41A;
}

/* 微型图表 */
.mini-chart {
  width: 100%;
  height: 120px;
  margin-top: 16px;
}

.chart-section {
  flex: 1;
  height: 200px;
  padding: 0 20px;
}

.pie-chart {
  width: 100%;
  height: 200px;
}

/* 附件区 */
.attachments-section {
  background-color: #FFFFFF;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);
  padding: 20px;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  color: #1D2129;
  margin-bottom: 16px;
}

.attachments-list {
  display: flex;
  gap: 16px;
}

.attachment-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  background-color: #F5F7FA;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.attachment-item:hover {
  background-color: #EEF7FF;
}

.file-icon {
  width: 40px;
  height: 40px;
  border-radius: 8px;
  background-size: 20px;
  background-repeat: no-repeat;
  background-position: center;
}

.pdf-icon {
  background-color: #FFECE8;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23F5222D' viewBox='0 0 24 24'%3E%3Cpath d='M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 2l5 5h-5V4zM9 13h2v2H9zm0 4h2v2H9zm4-4h2v6h-2z'/%3E%3C/svg%3E");
}

.excel-icon {
  background-color: #E8FFEA;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%2352C41A' viewBox='0 0 24 24'%3E%3Cpath d='M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 2l5 5h-5V4zm-3 7l2 3-2 3-2-3 2-3zm7 6h-2v-2h2v2zm0-4h-2v-2h2v2z'/%3E%3C/svg%3E");
}

.img-icon {
  background-color: #FFF7E6;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23FAAD14' viewBox='0 0 24 24'%3E%3Cpath d='M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z'/%3E%3C/svg%3E");
}

.file-name {
  font-size: 14px;
  color: #1D2129;
  font-weight: 500;
}

.file-size {
  font-size: 12px;
  color: #86909C;
}
</style>